package com.recipe.recipeservice.entity;

public enum Status
{
    PENDING,
    PUBLISHED,
    REJECTED
}
