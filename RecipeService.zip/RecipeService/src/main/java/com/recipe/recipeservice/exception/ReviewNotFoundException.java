package com.recipe.recipeservice.exception;

public class ReviewNotFoundException extends Exception
{
    public ReviewNotFoundException(String s)
    {
        super(s);
    }
}
