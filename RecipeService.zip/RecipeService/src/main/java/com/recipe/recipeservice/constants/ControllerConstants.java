package com.recipe.recipeservice.constants;

public class ControllerConstants {
    public static final String VIEW_RECIPE_PATH="/view-recipe";
    private ControllerConstants() {
        // Prevent instantiation
    }
}
