package com.recipe.recipeservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReviewDataDTO {
    private Long ratingId;
    private Integer rating;
    private String description;
    private String imgUrl;
}