package com.recipe.recipeservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeServiceApplicationTests {


}
